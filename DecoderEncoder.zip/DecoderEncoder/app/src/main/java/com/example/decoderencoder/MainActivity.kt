package com.example.decoderencoder

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import kotlinx.android.synthetic.main.item.*

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        var textRv = ArrayList<String>()

        var userText = findViewById<EditText>(R.id.tv)
        var decoder = findViewById<Button>(R.id.decoder)
        var encoder = findViewById<Button>(R.id.encoder)
        var rv = findViewById<RecyclerView>(R.id.rv)
        var ABC = "abcdefghijklmnopqrstuvwxyz"

        var name=""


        var stringtext=""


        var newLitter: Char
        var isupper = false
        rv.adapter = recycler(textRv)
        rv.layoutManager = LinearLayoutManager(this)

        encoder.setOnClickListener {
            var num: Int
            name=userText.text.toString()
            var j = ""
            for (i in name) {

                if (i.isUpperCase()) {
                    newLitter = i.toLowerCase()
                    isupper = true

                } else {
                    isupper = false
                    newLitter = i
                }
                if (ABC.contains(newLitter)) {
                    num = ABC.indexOf(newLitter)
                    num += 13
                    if (num > 25) {
                        num -= 26
                    }
                    if (isupper) {
                        j += ABC[num].toUpperCase()
                    } else {
                        j += ABC[num]
                    }
                } else {
                    j += newLitter
                }
                stringtext= "${j}"


            }
            textRv.add(stringtext)
            rv.adapter?.notifyDataSetChanged()
            println(stringtext)
       }

        decoder.setOnClickListener {
            var num: Int
            var j =""
            name=userText.text.toString()
            for (i in name) {
                if (i.isUpperCase()) {
                    newLitter = i.toLowerCase()
                    isupper = true

                } else {
                    isupper = false
                    newLitter = i
                }
                if (ABC.contains(newLitter)) {
                    num = ABC.indexOf(newLitter)
                    num -= 13
                    if (num < 0) {
                        num += 26
                    }
                    if (isupper) {
                        j += ABC[num].uppercase()

                    } else {
                        j += ABC[num]
                    }
                } else {
                    j += newLitter
                }
                stringtext= "${j}"


            }

            textRv.add(stringtext)
            rv.adapter?.notifyDataSetChanged()
            println(stringtext)

        }
    }
}




